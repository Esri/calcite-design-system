export const borderRadiusSharp24 = "M13 22h-2v-1h2v1zm-5-1H6v1h2v-1zm10 0h-2v1h2v-1zm4-13V6h-1v2h1zm0 5v-2h-1v2h1zm0 5v-2h-1v2h1zm0 0v-2h-1v2h1zM2 2v20h2v-1H3V3h18v1h1V2H2zm19 18v1h-1v1h2v-2h-1z";
