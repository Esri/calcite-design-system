export const blank32 = "";
