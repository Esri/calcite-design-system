export const blank24 = "";
