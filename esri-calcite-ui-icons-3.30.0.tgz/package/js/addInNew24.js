export const addInNew24 = "M19 5h4v1h-4v4h-1V6h-4V5h4V1h1zm1 7h1v10H2V3h10v9zm-9 1H3v8h8zm0-9H3v8h8zm9 9h-8v8h8z";
